package com.example.atividade_03aeronave;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    Button On;
    Button checklist;
    Button autorizacao;
    Button subir;
    Button autorizacao2;
    Button descer;
    Button Off;
    MultiAutoCompleteTextView textoArea;

    int Ligado = 0;
    int Autorizacao = 0;
    int Subir = 0;
    int Checklist = 0;

    int Autorizacao2 = 0;
    int Descer = 0;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        On = findViewById(R.id.On);
        checklist = findViewById(R.id.checklist);

        autorizacao = findViewById(R.id.autorizacao);

        subir = findViewById(R.id.subir);

        autorizacao2 = findViewById(R.id.autorizacao2);

        descer = findViewById(R.id.descer);

        Off = findViewById(R.id.Off);

        textoArea = findViewById(R.id.textoArea);
        checklist.setEnabled(false);
        autorizacao.setEnabled(false);
        subir.setEnabled(false);
        autorizacao2.setEnabled(false);
        Off.setEnabled(false);
        descer.setEnabled(false);
        Timer tempo = new Timer();
        Timer tempo2 = new Timer();
        Handler pararTempo = new Handler(Looper.getMainLooper());

        TimerTask tarefaSubir = new TimerTask() {
            @Override
            public void run() {
                textoArea.append("\nAeronave subindo...");
            }
        };
        TimerTask tarefaDescer = new TimerTask() {
            @Override
            public void run() {
                textoArea.append("\nAutorização concluída \nAeronave pousando");
            }
        };

        On.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Ligado == 0) {
                        textoArea.setText("Aeronave ligado");
                        Ligado = 1;
                        autorizacao.setEnabled(true);
                        Log.d(TAG, "Aeronave ligada");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao ligar a aeronave", e);
                }
            }
        });
        autorizacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Ligado == 1 && Autorizacao == 0) {
                        textoArea.setText("Aeronave ligado" + "\n" + "Autorização requerida");
                        Autorizacao = 1;
                        checklist.setEnabled(true);
                        Log.d(TAG, "Autorização requerida");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao requerer autorização", e);
                }
            }
        });
        checklist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Ligado == 1 && Autorizacao == 1 && Checklist == 0) {
                        textoArea.setText("Aeronave ligado\nAutorização requerida\nChecklist feito");
                        Checklist = 1;
                        subir.setEnabled(true);
                        Log.d(TAG, "Checklist feito");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao fazer checklist", e);
                }
            }
        });
        subir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Ligado == 1 && Autorizacao == 1 && Checklist == 1 && Subir == 0) {
                        textoArea.setText("Aeronave ligada\nAutorização requerida\nChecklist feito\nAeronave voando");
                        tempo.schedule(tarefaSubir, 0);
                        Log.d(TAG, "Aeronave subindo");
                        checklist.setEnabled(false);
                        autorizacao.setEnabled(false);
                        On.setEnabled(false);

                        pararTempo.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                tempo.cancel();
                                textoArea.append("\nAeronave parou de subir");
                                Log.d(TAG, "Aeronave parou de subir");
                            }
                        }, 5000);

                        Subir = 1;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao subir a aeronave", e);
                }
            }
        });

        autorizacao2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Ligado == 1 && Autorizacao == 1 && Checklist == 1 && Subir == 1 && Autorizacao2 == 0) {
                        textoArea.setText("Aeronave ligado\nAutorização requerida\nChecklist feito \nAeronave voando \n" +
                                "Autorização para descer requerida");
                        Autorizacao2 = 1;
                        Log.d(TAG, "Autorização para descer requerida");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao requerer autorização para descer", e);
                }
            }
        });
        descer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Ligado == 1 && Autorizacao == 1 && Checklist == 1 && Subir == 1 && Autorizacao2 == 1 && Descer == 0) {
                        textoArea.setText("Aeronave ligada\nAutorização requerida\nChecklist feito\nAeronave voando\n" +
                                "Autorização para descer requerida\n");
                        tempo2.schedule(tarefaDescer, 2000);
                        Log.d(TAG, "Aeronave descendo");

                        pararTempo.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                tempo2.cancel();
                                textoArea.append("\nAeronave pousado");
                                Log.d(TAG, "Aeronave pousado");
                            }
                        }, 5000);

                        Descer = 1;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao descer a aeronave", e);
                }
            }
        });

        Off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Ligado == 1){
                    textoArea.setText("Aeronave desligada");
                    checklist.setEnabled(false);
                    autorizacao.setEnabled(true);
                    subir.setEnabled(false);
                    autorizacao2.setEnabled(false);
                    Off.setEnabled(false);
                    descer.setEnabled(false);
                }
                else{
                    try {
                        if (Ligado == 1 && Autorizacao == 1 && Checklist == 1 && Subir == 1 && Autorizacao2 == 1 && Descer == 1) {
                            textoArea.setText("Aeronave ligado\nAutorização requerida\nChecklist feito\nAeronave voando\n" +
                                    "Autorização para descer requerida\nAutorização concluída\nAeronave descendo\nPouso de aeronave concluída\nAeronave desligada");
                            Ligado = 0;
                            Autorizacao =0;
                            Checklist = 0;
                            Subir =0;
                            Autorizacao2 = 0;
                            Descer = 0;
                            Log.d(TAG, "Aeronave desligada");
                            checklist.setEnabled(false);
                            autorizacao.setEnabled(false);
                            subir.setEnabled(false);
                            autorizacao2.setEnabled(false);
                            Off.setEnabled(false);
                            descer.setEnabled(false);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Erro ao desligar a aeronave", e);
                    }
                }

            }
        });
    }
}
